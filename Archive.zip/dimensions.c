/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dimensions.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smarwise <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/25 13:15:51 by smarwise          #+#    #+#             */
/*   Updated: 2018/07/28 13:18:44 by smarwise         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

t_rows		dimensions(int fd)
{
	t_rows	dimension;
	char	*line;

	line = NULL;
	dimension.rows = 0;
	while (get_next_line(fd, &line) == 1)
	{
		dimension.columns = ft_count_words(line);
		dimension.rows++;
		ft_strdel(&line);
	}
	return (dimension);
}
